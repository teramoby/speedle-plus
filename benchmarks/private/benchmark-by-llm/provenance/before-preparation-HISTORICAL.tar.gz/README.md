# authz-bench

Casbin、OPA、Speedle+ 用同一组策略做功能、性能、压力和易用性对比。结论见 [REPORT.md](REPORT.md)，交接用的完整测试计划见 [TEST_PLAN.md](TEST_PLAN.md)。

## 版本

| 引擎 | 版本 | 用法 |
|---|---|---|
| Casbin | `github.com/casbin/casbin/v3` v3.11.0 | 进程内库 |
| OPA | `github.com/open-policy-agent/opa` v1.21.4 | 进程内库（`v1/rego`），以及 `opa run --server` |
| Speedle+ | `github.com/teramoby/speedle-plus` v0.0.0-20261028230603-b27604c077ce | 进程内库（`pkg/eval`），以及 `speedle-ads` |

## 目录

- `scenarios/sN_*/`：9 个场景，每个场景三份策略：`casbin.conf` + `casbin.csv`、`opa.rego` + `opa.json`、`speedle.spdl`
- `engines.go`：三个引擎的统一接口 `Engine.Allowed(Req)`
- `scenarios_test.go`：场景用例和通过矩阵（`TestScenarios`）、策略体量（`TestPolicySize`）
- `capabilities_test.go`、`broken_test.go`：列权限、解释决策、运行时改策略、错误信息、坏策略的行为
- `gen.go`：生成大规模策略（n 个角色，每个角色 10 个用户），三种格式各一份
- `bench_test.go`：进程内延迟基准、并发基准、加载时间与内存（`TestLoadCost`）
- `cmd/authzd`：同一个精简 HTTP 服务包住任一引擎
- `cmd/loadgen`：闭环压测客户端，输出吞吐和 p50/p90/p99/p99.9
- `cmd/watchcheck`：验证 Speedle+ 文件监听在“写临时文件再改名”时的行为
- `stress.sh`：HTTP 压测（精简服务 ×3、`opa run --server`、`speedle-ads`）
- `results/`：原始结果

## 运行

```bash
go test -v -run 'TestScenarios|TestPolicySize|TestListPermissions|TestExplain|TestRuntimeUpdate|TestErrorMessages|TestBrokenPolicyBehavior' .
LOADCOST=1 go test -v -run TestLoadCost -timeout 0 .
go test -run '^$' -bench 'BenchmarkRBACMixed|BenchmarkRBACAllow|BenchmarkRBACDeny|BenchmarkABAC|BenchmarkWildcard' -benchtime=1s -count=5 -cpu 2 -timeout 0 .
go test -run '^$' -bench BenchmarkParallel -benchtime=1s -count=5 -cpu 4 -timeout 0 .
mkdir -p bin && go build -o bin/ ./cmd/authzd ./cmd/loadgen && go build -o bin/opa github.com/open-policy-agent/opa && go build -o bin/speedle-ads github.com/teramoby/speedle-plus/cmd/speedle-ads
./stress.sh 10000 15s "1 16 64"
```

在 Linux 机器上压测：`GOOS=linux GOARCH=amd64` 交叉编译 `bin/` 下四个程序，连同 `stress.sh` 拷过去，用 `BIN=./bin ./stress.sh` 运行。
