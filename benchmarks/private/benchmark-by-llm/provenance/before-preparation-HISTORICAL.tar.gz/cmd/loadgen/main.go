// Command loadgen is a closed-loop HTTP load generator for authorization
// endpoints. Each of -c workers sends one request at a time over a kept-alive
// connection for -d, after a -warmup that is not recorded.
//
// Requests pick a random role i in [1, n] and a random user of that role;
// 80% ask for /books/bookI (allowed), 20% for another role's book (denied),
// so no two consecutive requests are the same.
//
//	loadgen -target thin    -url http://127.0.0.1:9000/check
//	loadgen -target opa     -url http://127.0.0.1:8181/v1/data/authz/allow
//	loadgen -target speedle -url http://127.0.0.1:6734/authz-check/v1/is-allowed
package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math/rand/v2"
	"net/http"
	"os"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

func body(target string, user, res string) []byte {
	switch target {
	case "opa":
		return []byte(fmt.Sprintf(`{"input":{"user":%q,"action":"read","resource":%q}}`, user, res))
	case "speedle":
		return []byte(fmt.Sprintf(`{"subject":{"principals":[{"type":"user","name":%q}]},"serviceName":"app","resource":%q,"action":"read"}`, user, res))
	default:
		return []byte(fmt.Sprintf(`{"user":%q,"action":"read","resource":%q}`, user, res))
	}
}

// allowed extracts the decision from each server's response format.
func allowed(target string, b []byte) (bool, error) {
	var v map[string]any
	if err := json.Unmarshal(b, &v); err != nil {
		return false, err
	}
	key := "allowed"
	if target == "opa" {
		key = "result"
	}
	ok, isBool := v[key].(bool)
	if !isBool {
		return false, fmt.Errorf("no boolean %q in %s", key, b)
	}
	return ok, nil
}

func pct(sorted []time.Duration, p float64) time.Duration {
	if len(sorted) == 0 {
		return 0
	}
	i := int(p / 100 * float64(len(sorted)-1))
	return sorted[i]
}

func main() {
	target := flag.String("target", "thin", "thin | opa | speedle")
	url := flag.String("url", "http://127.0.0.1:9000/check", "endpoint")
	n := flag.Int("n", 10000, "number of roles in the policy set")
	c := flag.Int("c", 16, "concurrent workers")
	d := flag.Duration("d", 20*time.Second, "measured duration")
	warm := flag.Duration("warmup", 3*time.Second, "unrecorded warmup")
	label := flag.String("label", "", "row label")
	flag.Parse()

	tr := &http.Transport{MaxIdleConns: *c * 2, MaxIdleConnsPerHost: *c * 2, IdleConnTimeout: time.Minute}
	client := &http.Client{Transport: tr, Timeout: 10 * time.Second}

	var (
		wg        sync.WaitGroup
		recording atomic.Bool
		stop      atomic.Bool
		errs      atomic.Int64
		wrong     atomic.Int64
		mu        sync.Mutex
		all       []time.Duration
	)
	for w := 0; w < *c; w++ {
		wg.Add(1)
		go func(seed uint64) {
			defer wg.Done()
			rng := rand.New(rand.NewPCG(seed, seed*7+1))
			lat := make([]time.Duration, 0, 1<<16)
			for !stop.Load() {
				i := rng.IntN(*n) + 1
				user := fmt.Sprintf("user%d-%d", i, rng.IntN(10)+1)
				want := rng.IntN(10) < 8
				res := fmt.Sprintf("/books/book%d", i)
				if !want {
					res = fmt.Sprintf("/books/book%d", i%*n+1)
				}
				t0 := time.Now()
				resp, err := client.Post(*url, "application/json", bytes.NewReader(body(*target, user, res)))
				var got bool
				if err == nil {
					b, _ := io.ReadAll(resp.Body)
					resp.Body.Close()
					if resp.StatusCode != 200 {
						err = fmt.Errorf("status %d: %s", resp.StatusCode, strings.TrimSpace(string(b)))
					} else {
						got, err = allowed(*target, b)
					}
				}
				dt := time.Since(t0)
				if !recording.Load() {
					continue
				}
				if err != nil {
					if errs.Add(1) == 1 {
						fmt.Fprintln(os.Stderr, "first error:", err)
					}
					continue
				}
				if got != want {
					wrong.Add(1)
				}
				lat = append(lat, dt)
			}
			mu.Lock()
			all = append(all, lat...)
			mu.Unlock()
		}(uint64(w + 1))
	}
	time.Sleep(*warm)
	recording.Store(true)
	start := time.Now()
	time.Sleep(*d)
	recording.Store(false)
	elapsed := time.Since(start)
	stop.Store(true)
	wg.Wait()

	sort.Slice(all, func(i, j int) bool { return all[i] < all[j] })
	us := func(x time.Duration) string { return fmt.Sprintf("%.0f", float64(x.Nanoseconds())/1000) }
	fmt.Printf("| %s | %d | %.0f | %s | %s | %s | %s | %s | %d | %d |\n", *label, *c,
		float64(len(all))/elapsed.Seconds(), us(pct(all, 50)), us(pct(all, 90)), us(pct(all, 99)),
		us(pct(all, 99.9)), us(all[len(all)-1]), errs.Load(), wrong.Load())
}
