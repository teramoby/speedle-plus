# Casbin、OPA、Speedle+ 实测对比

测试日期 2026-10-29。测试机 shrek：Apple M1 Pro（8 核）、16 GB、macOS 27.0.1、Go 1.27.2。测试期间机器上还开着浏览器等应用，负载不低，所以每个基准跑 5 次取中位数。版本、目录和复现命令见 [README.md](README.md)。

三个引擎都按各自文档推荐的写法实现，每个请求的判定结果都和预期逐一核对过（基准和压测里也是）。Speedle+ 的维护者是委托这次测试的用户本人，所以下面对 Speedle+ 的问题写得比较细。

<!--TLDR-->

## 1. 功能：同一组 9 个场景

每个场景三份策略，放在 `scenarios/`。9 个场景三个引擎全部通过（30/30 个用例）。差别在怎么表达：

| 场景 | Casbin | OPA | Speedle+ |
|---|---|---|---|
| 基本 RBAC | ✅ | ✅ | ✅ |
| 角色继承 | ✅ `g, editor, viewer` | ✅ `graph.reachable` 求传递闭包 | ✅ `GRANT ROLE editor viewer` |
| 用户组 | ✅ 组成员关系要写进策略 | ✅ 组从请求里带入 | ✅ 组从请求里带入 |
| 多租户 | ✅ RBAC with domains | ✅ 数据按租户分层 | ✅ 授予角色时限定 `ON expr:/tenant1/.*`，租户要编码进资源路径 |
| ABAC：审批额度 | ✅ 每条规则带 `eval(p.cond)` | ✅ | ✅ `if amount <= 1000` |
| ABAC：只有所有者能改 | ✅ `r.sub == r.obj.Owner` | ✅ | ✅ 内置角色 `authenticated_role` 加 `request_user`（这个内置角色文档里没有，是从源码 `api/ads/types.go` 找到的） |
| 拒绝优先 | ✅ 要自己改 effect 表达式 | ✅ 要自己写 `not denied` | ✅ 内置规则：deny 覆盖 grant |
| 通配资源 | ✅ `keyMatch` | ✅ `glob.match` | ✅ `expr:` 正则 |
| 关系：文档在嵌套文件夹里 | ✅ `g2` 资源层级 | ✅ `graph.reachable` | ⚠️ 只能把层级编码进资源路径（`/F1/F1a/D3`），文档移动或有多个父级时就表达不了 |

写同样的 9 个场景需要的策略文本（非空行数，括号里是去掉空白后的字符数）：

| 场景 | Casbin | OPA | Speedle+ |
|---|---|---|---|
| 基本 RBAC | 15 (267) | 20 (472) | 7 (125) |
| 角色继承 | 15 (262) | 20 (460) | 8 (140) |
| 用户组 | 13 (219) | 14 (286) | 5 (71) |
| 多租户 | 15 (292) | 16 (416) | 7 (181) |
| ABAC：审批额度 | 13 (319) | 13 (271) | 6 (146) |
| ABAC：只有所有者能改 | 8 (152) | 8 (104) | 3 (86) |
| 拒绝优先 | 14 (297) | 20 (474) | 7 (123) |
| 通配资源 | 12 (230) | 13 (291) | 5 (88) |
| 关系 | 16 (293) | 15 (330) | 3 (48) |
| **合计** | **121 (2331)** | **139 (3104)** | **51 (1008)** |

Casbin 每个场景里有 9 行左右是重复的模型样板；Speedle+ 关系场景短，是因为用了路径编码这个弱一些的写法。

## 2. 决策之外的能力

| 能力 | Casbin | OPA | Speedle+ |
|---|---|---|---|
| 列出某用户的全部权限 | 内置 `GetImplicitPermissionsForUser` | 要自己写一条规则 | 内置 `GetAllGrantedPermissions` |
| 解释为什么拒绝 | `EnforceEx` 返回命中的那条规则：`[kim /hr/salaries read deny]` | 完整求值轨迹，这个例子 81 行 | `IsAllowed` 直接给原因 `DENY_POLICY_FOUND`；`Diagnose` 列出每条相关策略和它是否生效 |
| 运行时改策略 | `AddPolicy`，约 0.1 ms 生效 | 写 store，约 0.1–0.5 ms 生效 | 嵌入模式只能改文件，文件监听约 6 ms 生效；服务模式走 PMS API |
| 策略写错 | 加载不报错，第一次 `Enforce` 才报；信息没有位置（`No parameter 'p_ob' found.`） | 编译时报错，带文件名、行号和 `^` 定位 | 语法错误加载时就报，带 `^` 定位但没有行号；条件写错加载时不报，请求时返回 `ERROR_IN_EVALUATION` 并拒绝 |

几条错误信息原文：

```text
casbin  括号不配对:        Unbalanced parenthesis
casbin  p.obj 写成 p.ob:   No parameter 'p_ob' found.
opa     少一个右括号:      bad1.rego:14: rego_parse_error: unexpected contains keyword: expected \n or ; or }
opa     变量名写错:        bad2.rego:10: rego_unsafe_var_error: var permm is unsafe
speedle 少了资源:          Not found permission
                           GRANT ROLE admin read
                                                ^
speedle GRANT 写成 GRAN:   Not found valid effect
```

## 3. 性能

<!--BENCH-->

## 4. 易用性和学习曲线（普通用户视角）

站在一个要给 Go 服务加权限控制的普通开发者角度看。

**从零到第一个决策**

| | Casbin | OPA | Speedle+ |
|---|---|---|---|
| 安装 | `go get` 即可 | `go get`；命令行工具用 Homebrew 或下载二进制 | `go get` 只能拿到伪版本；服务模式要从源码编译三个程序，没有预编译版本 |
| 在浏览器里先试 | 在线编辑器 | Playground | Playground（speedle.io） |
| 嵌入 Go 的代码 | 2 个调用：`NewEnforcer`、`Enforce` | 6 步左右：读文件、建 store、`rego.New`、`PrepareForEval`、`Eval`、取结果 | 3 个调用，但请求结构要嵌套构造 `Subject`/`Principals` |
| 入门文档 | 齐全，中英文 | 最齐全，英文 | 网站 Quick Start 是新的且可用；README 和嵌入模式文档过时 |

**要学的东西**

- **Speedle+ 最平缓。** SPDL 读起来像英语句子：`GRANT ROLE manager approve /expense if amount <= 1000`。RBAC、ABAC、拒绝优先、用户组、按资源限定角色，都是一两行就写完，`Diagnose` 的输出对新手也好懂。代价是表达能力有边界：没有关系图模型，也不能写一般的计算逻辑，碰到边界只能靠外部自定义函数。
- **Casbin 起步快，深入后有坑。** 第一个 RBAC 例子十分钟能跑通，但模型 DSL 比较晦涩（`e = some(where (p.eft == allow)) && !some(where (p.eft == deny))`），一个 enforcer 只能用一个模型，ABAC 要把表达式字符串塞进 CSV 再 `eval()`。写错的模型加载时不报错，错误信息不给位置。规模上去以后还要知道两件事：matcher 里条件的顺序会让性能差几倍，规则多了要按租户拆分（官方性能文档就是这么建议的）。
- **OPA 最陡。** Rego 是从 Datalog 演化来的声明式语言：规则的多个定义是“或”，规则体的每行是“且”，还有 `some`/`every`、未定义值和 `false` 的区别、`data` 和 `input` 的区别，`unsafe var` 这类报错对新手不友好。好处是工具最全（`opa eval`、`opa test`、`opa fmt`、`opa check`、`opa bench`、REPL、覆盖率），错误信息精确到行，而且学会以后能用在 Kubernetes 准入、Envoy、Terraform 等很多地方。

**卡住的时候能找到多少帮助**：OPA 和 Casbin 有大量 issue、讨论和第三方文章；Speedle+ 几乎只能看官方文档和源码。对普通用户，这一点往往比语法难易更影响实际上手速度。

**学习曲线结论**：只做 RBAC/ABAC 的话，Speedle+ 最容易写也最容易读；Casbin 入门最快，但深入后的模型语法和性能调优有不少门道；OPA 前期投入最大，换来的是最强的表达能力和最好的工具。

## 5. 生态和成熟度

| | Casbin | OPA | Speedle+ |
|---|---|---|---|
| 治理 | Apache 孵化器（2026 年 2 月进入） | CNCF 毕业项目（2021 年 1 月） | teramoby 组织，原 Oracle Speedle 的分支 |
| GitHub star | 20.5k | 12.4k | 62（原版 oracle/speedle 159，已归档） |
| 贡献者 | 173 | 625 | 8（原版 14） |
| issue / PR 总数 | 942 / 674 | 3054 / 6354 | 12 / 111（原版 20 / 11） |
| 最近正式版本 | v3.11.0（2026-08-20） | v1.21.4（2026-10-23） | v2.0（2020-07-01），Go 模块代理上没有可用版本 |
| Stack Overflow 问题数 | 33（`casbin` 标签） | 270（`open-policy-agent`）+ 176（`rego`） | 没有标签 |
| 语言 | Go、Java、Node.js、Python、Rust、C++、.NET 等多语言原生实现 | Go 库；其他语言走 REST 服务或编译成 Wasm | Go 库；其他语言走 REST/gRPC（有 Java 客户端示例） |
| 集成 | 各语言 Web 框架中间件、几十种存储适配器 | Kubernetes（Gatekeeper）、Envoy、Terraform 等 | Kubernetes、Docker 示例；Istio 集成基于 Mixer，而 Mixer 在 Istio 1.8（2020 年 11 月）已删除 |

## 6. 测试中发现的 Speedle+ 问题

1. **嵌入模式下替换策略文件会让宿主进程退出。** `pkg/store/file/fileStore.go` 第 341、350、354 行在文件被删除、被改名或重新监听失败时调用 `log.Fatalf`。实测：原地写入能在约 10 ms 内重新加载；“写临时文件再改名覆盖”（`sed -i`、Ansible、很多编辑器都这样保存）会直接让进程以状态 1 退出（`cmd/watchcheck`）。建议改成记录错误、重新监听，保留旧策略继续服务。
2. **条件写错在加载时不报错。** `if amount <=` 这样的条件加载成功，只打一条日志；之后每个请求都返回 `ERROR_IN_EVALUATION`（会拒绝，不会放行），并且 `pkg/eval/runtimeservice.go` 第 94、118 行用 `fmt.Println` 把整条策略打到标准输出。建议加载时就报错，去掉这两处打印。
3. **没有可用的正式版本。** `v2.0` 不是 Go 认可的版本号，模块路径也没有 `/v2`，`go get ...@v2.0` 找不到版本，用户只能用伪版本。
4. **文档有过时和缺漏。** README 的构建说明还是 Go 1.13、GOPATH 和 `go get`（网站的 Quick Start 已经更新到 Go 1.25+）；嵌入模式文档还在讲 `dep`；Istio 集成基于已删除的 Mixer；内置角色 `authenticated_role`、`everyone_role`、`anonymous_role` 没有写进文档。

## 7. 这次测试的局限

- 只在一台忙碌的 macOS 笔记本上测；绝对数字会随机器变化，引擎之间的相对关系更可靠。
- 大规模策略只测了“每个角色一条权限、每角色 10 个用户”这一种形状，和 Speedle+ 自带基准一致。真实系统的策略形状不同，结果会不同，尤其是 Casbin（它的耗时和规则条数成正比）。
- OPA 的性能很依赖 Rego 的写法。这里用的是数据驱动、按 key 查找的写法；如果写成遍历全部规则，会慢很多。
- 没有测分布式部署（OPA bundle、Casbin watcher、Speedle+ etcd/MongoDB 存储）和高可用。
