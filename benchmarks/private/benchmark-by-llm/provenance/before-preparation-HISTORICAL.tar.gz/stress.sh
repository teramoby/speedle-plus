#!/usr/bin/env bash
# Load-test the three engines over HTTP.
#
#   ./stress.sh [roles] [duration] ["concurrency levels"]
#
# Thin HTTP rows: the same small net/http server (cmd/authzd) around each
# embedded engine. Official rows: `opa run --server` and Speedle+ `speedle-ads`
# (Casbin ships no HTTP server in its core library).
# Servers get SRV_PROCS cores and the load generator GEN_PROCS, via GOMAXPROCS.
set -euo pipefail
cd "$(dirname "$0")"
N=${1:-10000}; D=${2:-15s}; CS=${3:-"1 16 64"}
SRV_PROCS=${SRV_PROCS:-4}; GEN_PROCS=${GEN_PROCS:-4}
BIN=${BIN:-./bin}
WORK=$(mktemp -d)
trap 'kill $(jobs -p) 2>/dev/null || true; rm -rf "$WORK"' EXIT
read -r REGO JSON SPDL < <("$BIN/authzd" -gen "$WORK" -n "$N")

wait_ready() {
  for _ in $(seq 1 1200); do curl -s -o /dev/null "$1" && return 0; sleep 0.5; done
  echo "server at $1 not ready" >&2; return 1
}
run() { # label target url
  for c in $CS; do GOMAXPROCS=$GEN_PROCS "$BIN/loadgen" -target "$2" -url "$3" -n "$N" -c "$c" -d "$D" -label "$1"; done
}
stop() { kill "$1" 2>/dev/null || true; wait "$1" 2>/dev/null || true; }

echo "| setup | conc | req/s | p50 µs | p90 µs | p99 µs | p99.9 µs | max µs | errors | wrong |"
echo "|---|---|---|---|---|---|---|---|---|---|"
for e in ${ENGINES:-casbin opa speedle}; do
  GOMAXPROCS=$SRV_PROCS "$BIN/authzd" -engine "$e" -n "$N" -addr 127.0.0.1:9000 2>"$WORK/authzd-$e.log" &
  pid=$!; wait_ready http://127.0.0.1:9000/health
  run "thin HTTP + $e" thin http://127.0.0.1:9000/check
  stop $pid
done

GOMAXPROCS=$SRV_PROCS "$BIN/opa" run --server --addr 127.0.0.1:8181 --log-level error "$REGO" "$JSON" 2>"$WORK/opa.log" &
pid=$!; wait_ready http://127.0.0.1:8181/health
run "opa run --server" opa http://127.0.0.1:8181/v1/data/authz/allow
stop $pid

GOMAXPROCS=$SRV_PROCS "$BIN/speedle-ads" --store-type file --filestore-loc "$SPDL" --endpoint 127.0.0.1:6734 \
  --insecure=true --log-level error --auditlog-level error --enable-watch false >"$WORK/ads.log" 2>&1 &
pid=$!; wait_ready http://127.0.0.1:6734/authz-check/v1/is-allowed
run "speedle-ads" speedle http://127.0.0.1:6734/authz-check/v1/is-allowed
stop $pid
