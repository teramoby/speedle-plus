#!/usr/bin/env bash
# Run the whole comparison on this machine and write results/<host>/.
#
#   ./run-all.sh                       # every step
#   STEPS="bench stress" ./run-all.sh  # some steps
#
# Expects bin/authzbench.test (go test -c), bin/authzd, bin/loadgen, bin/opa
# and bin/speedle-ads. n=100000 runs one engine per process to keep memory
# down; Casbin at that size needs about 1 GB.
set -uo pipefail
cd "$(dirname "$0")"
BIN=${BIN:-./bin}
T="$BIN/authzbench.test"
OUT=results/$(hostname -s)
mkdir -p "$OUT"
STEPS=${STEPS:-"machine functional loadcost bench parallel stress"}
log() { echo "[$(date +%H:%M:%S)] $*"; }
bench() { "$T" -test.run '^$' -test.benchtime 1s -test.count 5 -test.timeout 0 "$@"; }

for step in $STEPS; do
  case $step in
  machine)
    {
      date; uname -a; echo "cores: $(getconf _NPROCESSORS_ONLN)"
      lscpu 2>/dev/null | grep -E "Model name|^CPU\(s\)|Thread|MHz" || sysctl -n machdep.cpu.brand_string
      free -h 2>/dev/null || sysctl hw.memsize
      uptime
    } > "$OUT/machine.txt" 2>&1 ;;
  functional)
    log functional
    "$T" -test.run 'TestScenarios|TestPolicySize' -test.v > "$OUT/functional.txt" 2>&1 ;;
  loadcost)
    log loadcost
    LOADCOST=1 "$T" -test.run TestLoadCost -test.v -test.timeout 0 > "$OUT/loadcost.txt" 2>&1 ;;
  bench)
    log "bench n<=10000"
    bench -test.cpu 2 -test.bench '^BenchmarkRBAC(Mixed|Allow|Deny)$/^n=(100|1000|10000)$/' > "$OUT/bench-seq.txt" 2>&1
    bench -test.cpu 2 -test.bench '^Benchmark(ABAC|Wildcard)$' >> "$OUT/bench-seq.txt" 2>&1
    : > "$OUT/bench-100k.txt"
    for e in speedle opa casbin-tuned casbin; do
      log "bench n=100000 $e"
      AUTHZ_ENGINES=$e bench -test.cpu 2 -test.bench '^BenchmarkRBAC(Mixed|Allow|Deny)$/^n=100000$/' >> "$OUT/bench-100k.txt" 2>&1
    done ;;
  parallel)
    log parallel
    bench -test.cpu 4 -test.bench '^BenchmarkParallel$' > "$OUT/bench-par.txt" 2>&1 ;;
  stress)
    log stress
    BIN=$BIN ./stress.sh 10000 15s "1 16 64" > "$OUT/stress.md" 2> "$OUT/stress.err" ;;
  esac
done
uptime >> "$OUT/machine.txt"
log "done: $OUT"
