// Licensed under the Universal Permissive License (UPL) Version 1.0.

package adsrest

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	"github.com/gorilla/mux"
	"github.com/teramoby/speedle-plus/pkg/cfg"
	"github.com/teramoby/speedle-plus/pkg/eval"
	"github.com/teramoby/speedle-plus/testutil/storetest"
)

// TestLocalDecisionService pins the local routes, decisions and readiness.
func TestLocalDecisionService(t *testing.T) {
	location := filepath.Join(t.TempDir(), "policies.json")
	if err := os.WriteFile(location, []byte(handlerPolicies), 0o600); err != nil {
		t.Fatal(err)
	}
	evaluator, err := eval.NewWithStore(&cfg.Config{}, storetest.PolicyStore(t, location))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = evaluator.(*eval.PolicyEvalImpl).Close() })
	router, err := NewRouter(evaluator)
	if err != nil {
		t.Fatal(err)
	}

	var routes []string
	if err := router.Walk(func(route *mux.Route, _ *mux.Router, _ []*mux.Route) error {
		routes = append(routes, route.GetName())
		return nil
	}); err != nil {
		t.Fatal(err)
	}
	want := []string{"Healthz", "Readyz", "GetAllGrantedPermissions", "GetAllGrantedRoles", "IsAllowed", "Diagnose", "Discover"}
	if !reflect.DeepEqual(routes, want) {
		t.Fatalf("routes = %v, want %v", routes, want)
	}

	for _, path := range []string{"is-allowed", "all-granted-roles", "all-granted-permissions"} {
		rec := post(t, router, path, `{`+alice+`,"resource":"res1","action":"read"}`, http.StatusOK)
		if source := rec.Header().Get("X-Speedle-Decision-Source"); source != "" {
			t.Fatalf("%s: decision source %q on a local decision", path, source)
		}
	}
	rec := post(t, router, "is-allowed", `{`+alice+`,"resource":"res1","action":"read"}`, http.StatusOK)
	var decision IsAllowedResponse
	if err := json.Unmarshal(rec.Body.Bytes(), &decision); err != nil || !decision.Allowed {
		t.Fatalf("local decision = %s, %v", rec.Body.String(), err)
	}

	probe := httptest.NewRecorder()
	router.ServeHTTP(probe, httptest.NewRequest(http.MethodGet, "/policy-source/v1/services", nil))
	if probe.Code != http.StatusNotFound {
		t.Fatalf("policy-source endpoint status = %d", probe.Code)
	}
	ready := httptest.NewRecorder()
	router.ServeHTTP(ready, httptest.NewRequest(http.MethodGet, "/readyz", nil))
	if ready.Code != http.StatusOK {
		t.Fatalf("readyz = %d (%s)", ready.Code, ready.Body.String())
	}
}

func TestLocalReadinessResponse(t *testing.T) {
	recorder := httptest.NewRecorder()
	(&RESTService{}).Readyz(recorder, httptest.NewRequest(http.MethodGet, "/readyz", nil))
	if recorder.Code != http.StatusOK || recorder.Header().Get("Cache-Control") != "no-store" {
		t.Fatalf("readiness: %d, %v", recorder.Code, recorder.Header())
	}
	var response map[string]interface{}
	if err := json.Unmarshal(recorder.Body.Bytes(), &response); err != nil {
		t.Fatal(err)
	}
	want := map[string]interface{}{"ready": true, "servicesTotal": float64(0), "servicesUsable": float64(0)}
	if !reflect.DeepEqual(response, want) {
		t.Fatalf("readiness: %v, want %v", response, want)
	}
}
