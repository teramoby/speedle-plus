//Copyright (c) 2018, Oracle and/or its affiliates. All rights reserved.
//Licensed under the Universal Permissive License (UPL) Version 1.0 as shown at http://oss.oracle.com/licenses/upl.

package eval

import (
	"fmt"
	"io"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/teramoby/speedle-plus/3rdparty/github.com/Knetic/govaluate"
	adsapi "github.com/teramoby/speedle-plus/api/ads"
	"github.com/teramoby/speedle-plus/api/pms"
	"github.com/teramoby/speedle-plus/pkg/errors"
	"github.com/teramoby/speedle-plus/pkg/eval/function"
	"github.com/teramoby/speedle-plus/pkg/logging"
	"github.com/teramoby/speedle-plus/pkg/subjectutils"
)

var builtinFunctions = map[string]govaluate.ExpressionFunction{
	"Sqrt":     function.Sqrt,
	"Max":      function.Max,
	"Min":      function.Min,
	"Sum":      function.Sum,
	"Avg":      function.Avg,
	"IsSubSet": function.IsSubSet,
}

type TokenAsserter interface {
	// set asserter func for policy evaluator
	SetAsserterFunc(f func(ctx *adsapi.RequestContext) error)
	// AssertToken assert token and generate subject to represent the identity
	AssertToken(ctx *adsapi.RequestContext) error
}

type InternalEvaluator interface {
	adsapi.PolicyEvaluator
	TokenAsserter
}

type internalRequestContext struct {
	Subject       *subject
	Service       *RuntimeService
	GlobalService *RuntimeService
	Resource      string
	Action        string
	Attributes    map[string]interface{}
}

type subject struct {
	Users      []string
	Groups     []string
	Entities   []string
	Principals []string
	TokenType  string
	Token      string
}

type PolicyEvalImpl struct {
	RuntimePolicyStore      *RuntimePolicyStore //This is runtime policy store
	Store                   pms.PolicyStoreManagerADS
	AsserterFunc            func(ctx *adsapi.RequestContext) error
	cleanupStop             chan struct{}
	closeOnce               sync.Once
	watchStopOnce           sync.Once
	closeErr                error
	cacheFailed             atomic.Bool
	cacheGate               sync.RWMutex
	healthChecker           pms.StoreHealthChecker
	healthMu                sync.Mutex
	lastHealthCheck         atomic.Int64 // UnixNano of the last finished probe
	storeFailureSince       time.Time
	storeFailureGracePeriod time.Duration
	watchStopped            atomic.Bool
	watchNeedsRestart       atomic.Bool
	watchManaged            bool
	watchLifecycleMu        sync.Mutex
	closed                  atomic.Bool
}

func (p *PolicyEvalImpl) deleteService(serviceName string) {
	// Delete application
	p.RuntimePolicyStore.deleteService(serviceName)
}

type reloadReadingStore interface {
	ReadPolicyStoreForReload() (*pms.PolicyStore, func(), error)
}

// readPolicyStoreForReload lets a distributing store bind its state transition
// to the exact generation the evaluator installs. Other stores keep their
// existing read path and have no acknowledgment to make.
func readPolicyStoreForReload(store pms.PolicyStoreManagerADS) (*pms.PolicyStore, func(), error) {
	if reader, ok := store.(reloadReadingStore); ok {
		return reader.ReadPolicyStoreForReload()
	}
	snapshot, err := store.ReadPolicyStore()
	return snapshot, nil, err
}

func (p *PolicyEvalImpl) fullReloadRuntimeCache() error {
	ps, acknowledge, err := readPolicyStoreForReload(p.Store)
	if err != nil {
		p.storeUnavailableLocked()
		logging.Default().Error(fmt.Sprintf("Fail to full reload runtime cache, err:%v", err))
		return err
	}
	if err := p.RuntimePolicyStore.reloadPolicyStore(ps); err != nil {
		p.cacheFailed.Store(true)
		return err
	}
	p.storeAvailableLocked()
	if acknowledge != nil {
		acknowledge()
	}
	return nil
}

func (p *PolicyEvalImpl) Refresh() (err error) {
	p.cacheGate.Lock()
	defer func() {
		if _, panicked := err.(*recoveredEvaluationError); panicked {
			p.cacheFailed.Store(true)
		}
		p.cacheGate.Unlock()
	}()
	defer recoverEvaluation("Refresh", &err)
	return p.fullReloadRuntimeCache()
}

// Store-event paths propagate mutation errors. The exported Add* methods keep
// their legacy no-result signatures; every rejection is logged and fails the cache.
func (p *PolicyEvalImpl) handleCacheMutation(err error) error {
	if err != nil {
		p.cacheFailed.Store(true)
		logging.Default().Error(fmt.Sprintf("Rejected runtime cache mutation: %v", err))
	}
	return err
}

func (p *PolicyEvalImpl) addServiceInRuntimeCache(service *pms.Service) error {
	return p.handleCacheMutation(p.RuntimePolicyStore.addService(service))
}

func (p *PolicyEvalImpl) AddServiceInRuntimeCache(service *pms.Service) {
	_ = p.addServiceInRuntimeCache(service)
}

func (p *PolicyEvalImpl) addPolicyInRuntimeCache(serviceName string, policy *pms.Policy) error {
	return p.handleCacheMutation(p.RuntimePolicyStore.addPolicy(serviceName, policy))
}

func (p *PolicyEvalImpl) AddPolicyInRuntimeCache(serviceName string, policy *pms.Policy) {
	_ = p.addPolicyInRuntimeCache(serviceName, policy)
}

func (p *PolicyEvalImpl) addRolePolicyInRuntimeCache(serviceName string, rolepolicy *pms.RolePolicy) error {
	return p.handleCacheMutation(p.RuntimePolicyStore.addRolePolicy(serviceName, rolepolicy))
}

func (p *PolicyEvalImpl) AddRolePolicyInRuntimeCache(serviceName string, rolepolicy *pms.RolePolicy) {
	_ = p.addRolePolicyInRuntimeCache(serviceName, rolepolicy)
}

func (p *PolicyEvalImpl) DeletePolicyInRuntimeCache(serviceName string, policyID string) {
	p.RuntimePolicyStore.deletePolicy(serviceName, policyID)
}
func (p *PolicyEvalImpl) DeleteRolePolicyInRuntimeCache(serviceName string, rolePolicyID string) {
	p.RuntimePolicyStore.deleteRolePolicy(serviceName, rolePolicyID)
}

func (p *PolicyEvalImpl) DeleteFunctionInRuntimeCache(funcName string) {
	p.RuntimePolicyStore.deleteFunction(funcName)
}

func (p *PolicyEvalImpl) addFunctionInRuntimeCache(cf *pms.Function) error {
	return p.handleCacheMutation(p.RuntimePolicyStore.addFunction(cf))
}

func (p *PolicyEvalImpl) AddFunctionInRuntimeCache(cf *pms.Function) {
	_ = p.addFunctionInRuntimeCache(cf)
}

func (p *PolicyEvalImpl) CleanExpiredFunctionResult() {
	var err error
	defer recoverEvaluation("FunctionResultCacheCleanup", &err)
	p.RuntimePolicyStore.expireFunctionResultCache()
}

func (p *PolicyEvalImpl) SetAsserterFunc(f func(ctx *adsapi.RequestContext) error) {
	p.AsserterFunc = f
}

// DistributionStore returns the backing store for custom service integrations.
// The evaluator does not interpret additional interfaces supplied by the store.
func (p *PolicyEvalImpl) DistributionStore() any {
	if p.Store == nil {
		return nil
	}
	return p.Store
}

func (p *PolicyEvalImpl) AssertToken(ctx *adsapi.RequestContext) (err error) {
	var original *adsapi.RequestContext
	defer func() {
		if err != nil && original != nil {
			*ctx = *original
		}
	}()
	defer recoverEvaluation("AssertToken", &err)
	// Assert identity token
	if ctx.Subject != nil &&
		p.AsserterFunc != nil &&
		len(ctx.Subject.TokenType) != 0 &&
		len(ctx.Subject.Token) != 0 && !ctx.Subject.Asserted {
		// Run on a private identity. A broken asserter can mark it trusted and
		// then panic; that partial identity must not survive a reused request.
		before := *ctx
		original = &before
		attributes, err := copyAssertionAttributes(ctx.Attributes)
		if err != nil {
			return err
		}
		ctx.Attributes = attributes
		identity := *ctx.Subject
		if ctx.Subject.Principals != nil {
			identity.Principals = make([]*adsapi.Principal, len(ctx.Subject.Principals))
			for i, principal := range ctx.Subject.Principals {
				if principal != nil {
					copy := *principal
					identity.Principals[i] = &copy
				}
			}
		}
		ctx.Subject = &identity
		err = p.AsserterFunc(ctx)
		if err == nil {
			if ctx.Subject == nil {
				return errors.New(errors.EvalEngineError, "identity asserter returned no subject")
			}
			if ctx.Subject == &identity {
				*original.Subject = identity
				ctx.Subject = original.Subject
			}
			ctx.Subject.Asserted = true
			commitAssertionAttributes(original.Attributes, attributes, &ctx.Attributes)
		}
		return err
	}

	return nil
}

func (p *PolicyEvalImpl) populateContext(ctx *adsapi.RequestContext) (*internalRequestContext, error) {
	service, err := p.getService(ctx.ServiceName)
	if err != nil {
		return nil, err
	}

	// Assert identity token
	err = p.AssertToken(ctx)
	if err != nil {
		return nil, err
	}

	var globalService *RuntimeService
	if ctx.ServiceName != pms.GlobalService {
		globalService, _ = p.getService(pms.GlobalService)
	}

	newCtx := internalRequestContext{
		Resource:      ctx.Resource,
		Action:        ctx.Action,
		Service:       service,
		GlobalService: globalService,
		Attributes:    make(map[string]interface{}),
	}

	now := time.Now()
	newCtx.Attributes[adsapi.BuiltIn_Attr_RequestTime] = now.Unix()
	year, month, day := now.Date()
	newCtx.Attributes[adsapi.BuiltIn_Attr_RequestYear] = year
	newCtx.Attributes[adsapi.BuiltIn_Attr_RequestMonth] = int(month)
	newCtx.Attributes[adsapi.BuiltIn_Attr_RequestDay] = day
	newCtx.Attributes[adsapi.BuiltIn_Attr_RequestWeekday] = now.Weekday().String()
	newCtx.Attributes[adsapi.BuiltIn_Attr_RequestHour] = now.Hour()

	newCtx.Subject = &subject{
		Users:    []string{},
		Groups:   []string{},
		Entities: []string{},
	}
	if ctx.Subject != nil {
		groups := []interface{}{}
		var user, entity interface{}
		for _, principal := range ctx.Subject.Principals {
			encodedPrincipal := subjectutils.EncodePrincipal(principal)
			principalWithoutIDD := ""
			if len(principal.IDD) != 0 {
				principalWithoutIDD = subjectutils.EncodePrincipal(&adsapi.Principal{
					Type: principal.Type,
					Name: principal.Name,
				})
			}
			switch principal.Type {
			case adsapi.PRINCIPAL_TYPE_USER:
				newCtx.Subject.Users = append(newCtx.Subject.Users, encodedPrincipal)
				if len(principalWithoutIDD) != 0 {
					newCtx.Subject.Users = append(newCtx.Subject.Users, principalWithoutIDD)
				}
				if user == nil {
					user = principal.Name
				}
			case adsapi.PRINCIPAL_TYPE_GROUP:
				newCtx.Subject.Groups = append(newCtx.Subject.Groups, encodedPrincipal)
				groups = append(groups, principal.Name)
				if len(principalWithoutIDD) != 0 {
					newCtx.Subject.Groups = append(newCtx.Subject.Groups, principalWithoutIDD)
				}
			case adsapi.PRINCIPAL_TYPE_ENTITY:
				newCtx.Subject.Entities = append(newCtx.Subject.Entities, encodedPrincipal)
				if len(principalWithoutIDD) != 0 {
					newCtx.Subject.Entities = append(newCtx.Subject.Entities, principalWithoutIDD)
				}
				if entity == nil {
					entity = principal.Name
				}
			}
		}
		if user != nil {
			newCtx.Attributes[adsapi.BuiltIn_Attr_RequestUser] = user
		}
		newCtx.Attributes[adsapi.BuiltIn_Attr_RequestGroups] = groups
		if entity != nil {
			newCtx.Attributes[adsapi.BuiltIn_Attr_RequestEntity] = entity
		}
	}
	newCtx.Attributes[adsapi.BuiltIn_Attr_RequestResource] = ctx.Resource
	newCtx.Attributes[adsapi.BuiltIn_Attr_RequestAction] = ctx.Action
	for key, value := range ctx.Attributes {
		newCtx.Attributes[key] = value
	}

	updateSubjectWithBuiltInRoles(newCtx.Subject)

	return &newCtx, nil
}

func (p *PolicyEvalImpl) IsAllowed(ctx adsapi.RequestContext) (bool, adsapi.Reason, error) {
	//IsAllowed don't need return EvaluationResult, so pass nil
	return p.InternalIsAllowed(&ctx, nil)
}

func (p *PolicyEvalImpl) InternalIsAllowed(ctx *adsapi.RequestContext, evaluationResult *adsapi.EvaluationResult) (allowed bool, reason adsapi.Reason, err error) {
	defer func() {
		if err != nil {
			allowed = false
			if _, recovered := err.(*recoveredEvaluationError); recovered {
				reason = adsapi.ERROR_IN_EVALUATION
			}
			if evaluationResult != nil {
				evaluationResult.Allowed = false
				evaluationResult.GrantedRoles = []string{}
				evaluationResult.RolePolicies = []*adsapi.EvaluatedRolePolicy{}
				evaluationResult.Policies = []*adsapi.EvaluatedPolicy{}
			}
		}
	}()
	defer recoverEvaluation("IsAllowed", &err)
	p.ensureStoreHealth()
	p.cacheGate.RLock()
	defer p.cacheGate.RUnlock()
	if err := p.cacheErrorLocked(); err != nil {
		return false, adsapi.ERROR_IN_EVALUATION, err
	}
	p.RuntimePolicyStore.RLock()
	defer p.RuntimePolicyStore.RUnlock()
	newCtx, err := p.populateContext(ctx)
	if err != nil {
		return false, adsapi.SERVICE_NOT_FOUND, err
	}
	newCtx.Service.RLock()
	defer newCtx.Service.RUnlock()
	if newCtx.Service.PoliciesCache.isEmpty() {
		return false, adsapi.NO_APPLICABLE_POLICIES, nil
	}

	if evaluationResult != nil {
		evaluationResult.Attributes = newCtx.Attributes
	}

	if err := p.resolveSubject(newCtx, evaluationResult); err != nil {
		return false, adsapi.ERROR_IN_EVALUATION, err
	}

	grantedPolicies, deniedPolicies, err := p.getPolicyList(newCtx, true, true, evaluationResult)
	if err != nil {
		return false, adsapi.ERROR_IN_EVALUATION, err
	}

	allowed, reason = denyOverwriteCombiner(grantedPolicies, deniedPolicies, newCtx, evaluationResult)
	return allowed, reason, nil
}

// Return all the policies related to a subject
func (p *PolicyEvalImpl) Diagnose(ctx adsapi.RequestContext) (*adsapi.EvaluationResult, error) {
	// Construct the evaluation result
	retCtx := ctx
	evaResult := adsapi.EvaluationResult{
		Allowed:      false,
		RequestCtx:   &retCtx,
		Attributes:   nil,
		GrantedRoles: make([]string, 0),
		RolePolicies: make([]*adsapi.EvaluatedRolePolicy, 0),
		Policies:     make([]*adsapi.EvaluatedPolicy, 0),
	}
	allowed, reason, err := p.InternalIsAllowed(&ctx, &evaResult)
	evaResult.Allowed = allowed
	evaResult.Reason = reason

	return &evaResult, err
}

func (p *PolicyEvalImpl) GetAllGrantedRoles(ctx adsapi.RequestContext) (roles []string, err error) {
	defer func() {
		if err != nil {
			roles = nil
		}
	}()
	defer recoverEvaluation("GetAllGrantedRoles", &err)
	p.ensureStoreHealth()
	p.cacheGate.RLock()
	defer p.cacheGate.RUnlock()
	if err := p.cacheErrorLocked(); err != nil {
		return nil, err
	}
	p.RuntimePolicyStore.RLock()
	defer p.RuntimePolicyStore.RUnlock()
	newCtx, err := p.populateContext(&ctx)
	if err != nil {
		return nil, err
	}
	newCtx.Service.RLock()
	defer newCtx.Service.RUnlock()

	ret, err := p.getGrantedRolesFromService(newCtx, nil)
	return ret, err
}

// Limitations: This function only calculate granted permissions with resource, will not calculate granted permissions with resource expression.
func (p *PolicyEvalImpl) GetAllGrantedPermissions(ctx adsapi.RequestContext) (permissions []pms.Permission, err error) {
	defer func() {
		if err != nil {
			permissions = nil
		}
	}()
	defer recoverEvaluation("GetAllGrantedPermissions", &err)
	p.ensureStoreHealth()
	p.cacheGate.RLock()
	defer p.cacheGate.RUnlock()
	if err := p.cacheErrorLocked(); err != nil {
		return nil, err
	}
	p.RuntimePolicyStore.RLock()
	defer p.RuntimePolicyStore.RUnlock()
	newCtx, err := p.populateContext(&ctx)
	if err != nil {
		return nil, err
	}

	newCtx.Service.RLock()
	defer newCtx.Service.RUnlock()
	if newCtx.Service.PoliciesCache.isEmpty() {
		return []pms.Permission{}, nil
	}

	if err := p.resolveSubject(newCtx, nil); err != nil {
		return nil, err
	}

	grantedPolicies, deniedPolicies, err := p.getPolicyList(newCtx, false, true, nil)
	if err != nil {
		return nil, err
	}

	var grantedPermissionList, deniedPermissionList []pms.Permission
	for _, policy := range grantedPolicies {
		permissions := policy.Permissions
		if permissions == nil { //means grant any permissions, ignore here
			continue
		}
		for _, permission := range permissions {
			if len(permission.Resource) != 0 {
				grantedPermissionList = append(grantedPermissionList, pms.Permission{
					Resource: permission.Resource,
					Actions:  permission.Actions,
				})
			}
		}
	}
	for _, policy := range deniedPolicies {
		permissions := policy.Permissions
		if len(permissions) == 0 { //means deny any permission
			return []pms.Permission{}, nil
		}
		for _, permission := range permissions {
			deniedPermissionList = append(deniedPermissionList, pms.Permission{
				Resource:           permission.Resource,
				Actions:            permission.Actions,
				ResourceExpression: permission.ResourceExpression,
			})
		}
	}

	ret := calculatePermissions(&newCtx.Service.PoliciesCache.Expressions, grantedPermissionList, deniedPermissionList)
	return ret, nil
}

func (p *PolicyEvalImpl) getService(serviceName string) (*RuntimeService, error) {
	if runtimeService, exist := p.RuntimePolicyStore.RuntimeServices[serviceName]; exist {
		return runtimeService, nil
	}
	return nil, errors.Errorf(errors.EvalEngineError, "Application %s is not found ", serviceName)
}

func (p *PolicyEvalImpl) resolveSubject(ctx *internalRequestContext, evaluationResult *adsapi.EvaluationResult) error {
	roles, err := p.getGrantedRolesFromService(ctx, evaluationResult)
	if err != nil {
		return err
	}
	for _, role := range roles {
		ctx.Subject.Principals = append(ctx.Subject.Principals, convertRoleToPrincipal(role))
	}

	//Set EvalutionResult
	if evaluationResult != nil {
		evaluationResult.GrantedRoles = roles
	}

	return nil
}

// The firstly returned is granted rolePolicies.
// The second returned value is denied rolePolicies.
func (p *PolicyEvalImpl) getDirectRolePolices(principals []string,
	ctx *internalRequestContext, policyIDMap map[string]bool, evaluationResult *adsapi.EvaluationResult) ([]*pms.RolePolicy, []*pms.RolePolicy, error) {

	grantedRolePolicies := make([]*pms.RolePolicy, 0)
	deniedRolePolicies := make([]*pms.RolePolicy, 0)
	grantedRolePolicies, deniedRolePolicies, err := p.getDirectRolePolicesInService(principals, ctx.Service, ctx.Resource, ctx.Attributes, policyIDMap, evaluationResult, grantedRolePolicies, deniedRolePolicies)
	if err != nil {
		return nil, nil, err
	}
	if ctx.GlobalService != nil {
		grantedRolePolicies, deniedRolePolicies, err = p.getDirectRolePolicesInService(principals, ctx.GlobalService, ctx.Resource, ctx.Attributes, policyIDMap, evaluationResult, grantedRolePolicies, deniedRolePolicies)
		if err != nil {
			return nil, nil, err
		}
	}
	return grantedRolePolicies, deniedRolePolicies, nil
}

func (p *PolicyEvalImpl) getDirectRolePolicesInService(principals []string,
	service *RuntimeService, resource string, attributes map[string]interface{}, policyIDMap map[string]bool, evaluationResult *adsapi.EvaluationResult, grantedRolePolicies []*pms.RolePolicy, deniedRolePolicies []*pms.RolePolicy) ([]*pms.RolePolicy, []*pms.RolePolicy, error) {
	for _, policy := range service.GetRelatedRolePolicyMap(principals, resource) {

		if policyIDMap[policy.ID] {
			continue
		}

		// No principal defined. that means the roles are granted to any user
		if (len(policy.Principals) == 0 || matchRolePolicyPrincipals(principals, policy.Principals)) && matchResource(&service.RolePoliciesCache.Expressions, resource, policy.Resources, policy.ResourceExpressions) {
			// Evaluate conditions
			condition, ok := service.RolePoliciesCache.Conditions[policy.ID]
			// If no conditions defined, the condition evaluation result is true
			result := true
			if !ok && len(policy.Condition) != 0 {
				if cond, err := p.RuntimePolicyStore.recompileRolePolicyConditionAtRuntime(service.Name, policy); err != nil {
					return nil, nil, err
				} else {
					condition = cond
				}
			}
			if condition != nil {
				result, _ = evaluateCondition(condition, attributes)
			}

			if evaluationResult != nil {
				evaluationResult.AddRolePolicy(policy, result)
			}
			if result {
				switch policy.Effect {
				case pms.Grant:
					grantedRolePolicies = append(grantedRolePolicies, policy)
				case pms.Deny:
					deniedRolePolicies = append(deniedRolePolicies, policy)
				default:
					// TODO: Log a warning, currently do nothing
				}
			}
		}
	}
	return grantedRolePolicies, deniedRolePolicies, nil
}

type Role struct {
	Name               string
	ParentPrincipals   map[string]bool
	ParentRoles        map[string]bool
	ChildRoles         map[string]bool
	DeniedRoles        map[string]bool
	DeniedByRoles      map[string]bool
	DeniedByPrincipals map[string]bool //TODO this could be removed?
}

// assume role policy does not support AND Principal
// assume ctx.Subject.Principals does not contain user defined roles,
// assume built-in role like anonymous role and authenticated role can't be used in role policy
func (p *PolicyEvalImpl) getGrantedRolesFromService(ctx *internalRequestContext, evaluationResult *adsapi.EvaluationResult) ([]string, error) {
	if ctx.GlobalService != nil {
		ctx.GlobalService.RLock()
		defer ctx.GlobalService.RUnlock()
	}

	relatedRolesMap := make(map[string]*Role) //contain all role info related to the role calculation
	policyIDMap := make(map[string]bool)      // this is to avoid repeat processing of same policy.
	grantedRoleMap := make(map[string]bool)   //this is to keep all possiblely granted roles

	subjectPrincipalMap := make(map[string]bool) //this contains non-role principals of ctx.Subject
	for _, principal := range ctx.Subject.Principals {
		if !strings.HasPrefix(principal, "role:") {
			subjectPrincipalMap[principal] = true
		}
	}
	directGrantedRolePolicies, directDeniedRolePolicies, err := p.getDirectRolePolices(ctx.Subject.Principals, ctx, policyIDMap, evaluationResult)
	if err != nil {
		return nil, err
	}

	directDeniedRoleMap := make(map[string]bool) //roles directly denied by user/group in ctx.subject , which always could be denied safely
	deniedRoleMap := make(map[string]bool)       //this contains roles possiblely denied by another role.
	var newlyGrantedRoles []string

	for _, rolePolicy := range directDeniedRolePolicies {
		if _, ok := policyIDMap[rolePolicy.ID]; !ok {
			policyIDMap[rolePolicy.ID] = true
			updateRelatedRoleMapWithDenyRolePolicy(rolePolicy, relatedRolesMap, subjectPrincipalMap, directDeniedRoleMap, grantedRoleMap, deniedRoleMap)
		}
	}

	for _, rolePolicy := range directGrantedRolePolicies {
		if _, ok := policyIDMap[rolePolicy.ID]; !ok {
			policyIDMap[rolePolicy.ID] = true
			newlyGrantedRoles = append(newlyGrantedRoles, updateRelatedRoleMapWithGrantRolePolicy(rolePolicy, relatedRolesMap, subjectPrincipalMap, directDeniedRoleMap, grantedRoleMap)...)
		}
	}

	for len(newlyGrantedRoles) != 0 {
		newSubjectPrincipals := []string{}
		for _, role := range newlyGrantedRoles {
			newSubjectPrincipals = append(newSubjectPrincipals, convertRoleToPrincipal(role))
		}
		indirectGrantedRolePolicies, _, err := p.getDirectRolePolices(newSubjectPrincipals, ctx, policyIDMap, evaluationResult)
		if err != nil {
			return nil, err
		}

		newlyGrantedRoles = []string{}
		for _, rolePolicy := range indirectGrantedRolePolicies {
			if _, ok := policyIDMap[rolePolicy.ID]; !ok {
				policyIDMap[rolePolicy.ID] = true
				newlyGrantedRoles = append(newlyGrantedRoles, updateRelatedRoleMapWithGrantRolePolicy(rolePolicy, relatedRolesMap, subjectPrincipalMap, directDeniedRoleMap, grantedRoleMap)...)
			}
		}
	}

	newSubjectPrincipals := []string{}
	for role := range grantedRoleMap {
		newSubjectPrincipals = append(newSubjectPrincipals, convertRoleToPrincipal(role))
	}
	_, DeniedRolePolicies, err := p.getDirectRolePolices(newSubjectPrincipals, ctx, policyIDMap, evaluationResult)
	if err != nil {
		return nil, err
	}

	for _, rolePolicy := range DeniedRolePolicies {
		if _, ok := policyIDMap[rolePolicy.ID]; !ok {
			policyIDMap[rolePolicy.ID] = true
			updateRelatedRoleMapWithDenyRolePolicy(rolePolicy, relatedRolesMap, subjectPrincipalMap, directDeniedRoleMap, grantedRoleMap, deniedRoleMap)
		}
	}
	//only keep role node that is in possible granted roles
	cleanRelatedRoleMap(relatedRolesMap, grantedRoleMap)

	for {
		//find safely denied role
		safelyDeniedRoles := []string{}
		for deniedRole := range deniedRoleMap {
			safe, err := couldRoleSafelyBeDenied(deniedRole, relatedRolesMap, deniedRoleMap)
			if err != nil {
				return nil, err
			}
			if safe {
				safelyDeniedRoles = append(safelyDeniedRoles, deniedRole)
			}
		}

		if len(safelyDeniedRoles) > 0 {
			for _, deniedRole := range safelyDeniedRoles {
				denyRoleAndDescendants(deniedRole, relatedRolesMap, grantedRoleMap, deniedRoleMap)
			}
			//get deniedRoles based on the left role nodes.
			deniedRoleMap = getDeniedRoles(relatedRolesMap, grantedRoleMap)

			continue
		} else {
			//when no safely denied roles found, just delete all denied roles one by one
			for deniedRole := range deniedRoleMap {
				denyRoleAndDescendants(deniedRole, relatedRolesMap, grantedRoleMap, deniedRoleMap)
			}
			break
		}

	}
	finalGrantedRoles := []string{}
	for role := range grantedRoleMap {
		finalGrantedRoles = append(finalGrantedRoles, role)
	}

	return finalGrantedRoles, nil
}

func updateRelatedRoleMapWithGrantRolePolicy(rolePolicy *pms.RolePolicy, relatedRolesMap map[string]*Role,
	subjectPrincipalMap map[string]bool, directDeniedRoleMap map[string]bool, grantedRoleMap map[string]bool) []string {

	newlyGrantedRoles := []string{}

	parentRoles := []string{}
	parentPrincipals := []string{}

	for _, principal := range rolePolicy.Principals {
		if strings.HasPrefix(principal, "role:") {
			parentRoles = append(parentRoles, strings.TrimPrefix(principal, "role:"))
		} else {
			if _, ok := subjectPrincipalMap[principal]; ok {
				parentPrincipals = append(parentPrincipals, principal)
			}
		}
	}

	for _, role := range rolePolicy.Roles {
		if _, ok := directDeniedRoleMap[role]; !ok {
			roleNode, ok := relatedRolesMap[role]
			if !ok {
				roleNode = &Role{
					Name:               role,
					ParentPrincipals:   make(map[string]bool),
					ParentRoles:        make(map[string]bool),
					ChildRoles:         make(map[string]bool),
					DeniedRoles:        make(map[string]bool),
					DeniedByRoles:      make(map[string]bool),
					DeniedByPrincipals: make(map[string]bool),
				}
				relatedRolesMap[role] = roleNode
			}
			for _, proleName := range parentRoles {
				roleNode.ParentRoles[proleName] = true
			}
			for _, pprincipalName := range parentPrincipals {
				roleNode.ParentPrincipals[pprincipalName] = true
			}
			if _, ok := grantedRoleMap[role]; !ok {
				grantedRoleMap[role] = true
				newlyGrantedRoles = append(newlyGrantedRoles, role)
			}

		}
	}
	for _, proleName := range parentRoles {
		parentRoleNode, ok := relatedRolesMap[proleName]
		if !ok {
			parentRoleNode = &Role{
				Name:               proleName,
				ParentPrincipals:   make(map[string]bool),
				ParentRoles:        make(map[string]bool),
				ChildRoles:         make(map[string]bool),
				DeniedRoles:        make(map[string]bool),
				DeniedByRoles:      make(map[string]bool),
				DeniedByPrincipals: make(map[string]bool),
			}
			relatedRolesMap[proleName] = parentRoleNode
		}
		for _, childRole := range rolePolicy.Roles {
			if _, ok := directDeniedRoleMap[childRole]; !ok {
				parentRoleNode.ChildRoles[childRole] = true
			}
		}
	}

	return newlyGrantedRoles
}

func updateRelatedRoleMapWithDenyRolePolicy(rolePolicy *pms.RolePolicy, relatedRolesMap map[string]*Role,
	subjectPrincipalMap map[string]bool, directDeniedRoleMap map[string]bool, grantedRoleMap map[string]bool,
	deniedRoleMap map[string]bool) {

	deniedByRoles := []string{}
	deniedByPrincipals := []string{}

	for _, principal := range rolePolicy.Principals {
		if strings.HasPrefix(principal, "role:") {
			deniedByRoles = append(deniedByRoles, strings.TrimPrefix(principal, "role:"))
		} else {
			if _, ok := subjectPrincipalMap[principal]; ok {
				deniedByPrincipals = append(deniedByPrincipals, principal)
			}
		}
	}

	for _, role := range deniedByRoles {
		roleNode, ok := relatedRolesMap[role]
		if !ok {
			roleNode = &Role{
				Name:               role,
				ParentPrincipals:   make(map[string]bool),
				ParentRoles:        make(map[string]bool),
				ChildRoles:         make(map[string]bool),
				DeniedRoles:        make(map[string]bool),
				DeniedByRoles:      make(map[string]bool),
				DeniedByPrincipals: make(map[string]bool),
			}
			relatedRolesMap[role] = roleNode
		}
		for _, deniedRole := range rolePolicy.Roles {
			roleNode.DeniedRoles[deniedRole] = true
		}
	}
	for _, role := range rolePolicy.Roles {
		roleNode, ok := relatedRolesMap[role]
		if !ok {
			roleNode = &Role{
				Name:               role,
				ParentPrincipals:   make(map[string]bool),
				ParentRoles:        make(map[string]bool),
				ChildRoles:         make(map[string]bool),
				DeniedRoles:        make(map[string]bool),
				DeniedByRoles:      make(map[string]bool),
				DeniedByPrincipals: make(map[string]bool),
			}
			relatedRolesMap[role] = roleNode
		}
		for _, deniedByRole := range deniedByRoles {
			roleNode.DeniedByRoles[deniedByRole] = true
		}
		for _, deniedByPrincipal := range deniedByPrincipals {
			roleNode.DeniedByPrincipals[deniedByPrincipal] = true
		}

		if len(deniedByPrincipals) > 0 {
			directDeniedRoleMap[role] = true
		} else {
			if _, ok := grantedRoleMap[role]; ok {
				if _, ok := deniedRoleMap[role]; !ok {
					deniedRoleMap[role] = true
				}
			}
		}
	}
}

func cleanRelatedRoleMap(relatedRoleMap map[string]*Role, grantedRoleMap map[string]bool) {
	for role, roleNode := range relatedRoleMap {
		if _, ok := grantedRoleMap[role]; !ok {
			delete(relatedRoleMap, role)
		} else {
			for pRole := range roleNode.ParentRoles {
				if _, ok := grantedRoleMap[pRole]; !ok {
					delete(roleNode.ParentRoles, pRole)
				}
			}
			for pRole := range roleNode.DeniedByRoles {
				if _, ok := grantedRoleMap[pRole]; !ok {
					delete(roleNode.DeniedByRoles, pRole)
				}
			}
			for cRole := range roleNode.ChildRoles {
				if _, ok := grantedRoleMap[cRole]; !ok {
					delete(roleNode.ChildRoles, cRole)
				}
			}
			for cRole := range roleNode.DeniedRoles {
				if _, ok := grantedRoleMap[cRole]; !ok {
					delete(roleNode.DeniedRoles, cRole)
				}
			}
		}
	}
}

func getDeniedRoles(relatedRoleMap map[string]*Role, grantedRoleMap map[string]bool) map[string]bool {
	deniedRoleMap := make(map[string]bool)
	for role, roleNode := range relatedRoleMap {
		if len(roleNode.DeniedByRoles) > 0 {
			if _, ok := grantedRoleMap[role]; ok {
				deniedRoleMap[role] = true
			}
		}
	}
	return deniedRoleMap
}

func denyRoleAndDescendants(role string, relatedRoleMap map[string]*Role, grantedRoleMap map[string]bool, deniedRoleMap map[string]bool) {
	deletedRoles := make(map[string]bool)
	deletedRoles[role] = true
	descendants := getDeniableDescendantRoles(role, relatedRoleMap)
	//fmt.Printf("deniable descendants for %s are %v \n", role, descendants)
	for _, d := range descendants {
		deletedRoles[d] = true
	}
	for role, roleNode := range relatedRoleMap {
		if _, ok := deletedRoles[role]; !ok {
			for deletedRole := range deletedRoles {
				delete(roleNode.ChildRoles, deletedRole)
				delete(roleNode.ParentRoles, deletedRole)
				delete(roleNode.DeniedRoles, deletedRole)
				delete(roleNode.DeniedByRoles, deletedRole)
				if len(roleNode.ParentRoles) == 0 && len(roleNode.ParentPrincipals) == 0 {
					delete(relatedRoleMap, role)
					delete(grantedRoleMap, role)
				}
			}
		}
	}
	for deletedRole := range deletedRoles {
		delete(relatedRoleMap, deletedRole)
		delete(grantedRoleMap, deletedRole)
	}
	delete(deniedRoleMap, role)
}

func getDeniableDescendantRoles(role string, relatedRoleMap map[string]*Role) []string {
	return deniableDescendantRoles(role, relatedRoleMap, map[string]bool{role: true})
}

// deniableDescendantRoles retains the existing depth-first selection rules,
// using an explicit stack so deep acyclic graphs cannot overflow the Go stack.
func deniableDescendantRoles(role string, roles map[string]*Role, visited map[string]bool) []string {
	type frame struct {
		role        string
		children    []string
		next, start int
	}
	makeFrame := func(name string, start int) frame {
		f := frame{role: name, start: start}
		if node := roles[name]; node != nil {
			for child := range node.ChildRoles {
				f.children = append(f.children, child)
			}
		}
		return f
	}
	stack := []frame{makeFrame(role, 0)}
	descendants := []string{}
	// Each recursive call previously had its own descendants slice. start
	// marks that slice in this shared output; earlier ancestor branches are
	// deliberately outside the current frame, preserving the legacy rule.
	positions := make(map[string]int)
	for len(stack) > 0 {
		f := &stack[len(stack)-1]
		if f.next == len(f.children) {
			stack = stack[:len(stack)-1]
			continue
		}
		child := f.children[f.next]
		f.next++
		if visited[child] {
			continue
		}
		node := roles[child]
		if node == nil || len(node.ParentPrincipals) > 0 {
			continue
		}
		allDenied := true
		for parent := range node.ParentRoles {
			index, exists := positions[parent]
			if parent != f.role && (!exists || index < f.start) {
				allDenied = false
				break
			}
		}
		if allDenied {
			visited[child] = true
			positions[child] = len(descendants)
			descendants = append(descendants, child)
			stack = append(stack, makeFrame(child, len(descendants)))
		}
	}
	return descendants
}

// If any of the deniedByRole and all its ancestors are not denied, we take it as could be safely denied.
func couldRoleSafelyBeDenied(role string, relatedRoleMap map[string]*Role, deniedRoleMap map[string]bool) (bool, error) {
	if roleNode, ok := relatedRoleMap[role]; ok {
		for deniedByRole := range roleNode.DeniedByRoles {
			denied, err := selfOrAncestorsBeDenied(deniedByRole, relatedRoleMap, deniedRoleMap)
			if err != nil {
				return false, err
			}
			if !denied {
				return true, nil
			}
		}
	} else {
		logging.Default().Warn(fmt.Sprintf("Role %q is not in the related role map", role))
	}
	return false, nil
}

// Search iteratively for an independent subject source, excluding denied roles.
// A back edge alone does not fail: a valid cycle can still reach such a source.
// Only a closed cycle with no source is an unresolved dependency.
func selfOrAncestorsBeDenied(role string, roles map[string]*Role, denied map[string]bool) (bool, error) {
	type frame struct {
		name string
		exit bool
	}
	stack := []frame{{name: role}}
	color := make(map[string]uint8)
	cyclic := false
	for len(stack) > 0 {
		f := stack[len(stack)-1]
		stack = stack[:len(stack)-1]
		if f.exit {
			color[f.name] = 2
			continue
		}
		if denied[f.name] {
			continue
		}
		if color[f.name] == 1 {
			cyclic = true
			continue
		}
		if color[f.name] == 2 {
			continue
		}
		node, ok := roles[f.name]
		if !ok {
			continue
		}
		if len(node.ParentPrincipals) > 0 {
			return false, nil
		}
		color[f.name] = 1
		stack = append(stack, frame{name: f.name, exit: true})
		for parent := range node.ParentRoles {
			stack = append(stack, frame{name: parent})
		}
	}
	if cyclic {
		logging.Default().Error("role dependency cycle has no independent subject source")
		return false, errors.New(errors.EvalEngineError, "role dependency cycle has no independent subject source")
	}
	return true, nil
}

// Returns granted and denied policies
// The first returned value is granted policies
// The second returned value is denied policies
func (p *PolicyEvalImpl) getPolicyList(ctx *internalRequestContext, matchResource bool, matchCondition bool, evaluationResult *adsapi.EvaluationResult) ([]*pms.Policy, []*pms.Policy, error) {
	var grantedPolicyList []*pms.Policy
	var deniedPolicyList []*pms.Policy

	principals := ctx.Subject.Principals
	for _, policy := range ctx.Service.GetRelatedPolicyMap(principals, ctx.Resource, matchResource) {
		// No principal defined. that means the resource actions are granted to any user
		if len(policy.Principals) == 0 || matchPrincipals(principals, policy.Principals) {
			// Check the resource and action
			if !matchResource || (matchResource && matchResourceAction(&ctx.Service.PoliciesCache.Expressions, policy, ctx)) {
				// Evaluate conditions
				condition, ok := ctx.Service.PoliciesCache.Conditions[policy.ID]
				// If no conditions defined, the condition evaluation result is true
				result := true
				if !ok && len(policy.Condition) != 0 {
					if cond, err := p.RuntimePolicyStore.recompilePolicyConditionAtRuntime(ctx.Service.Name, policy); err != nil {
						return nil, nil, err
					} else {
						condition = cond
					}
				}
				if condition != nil {
					result, _ = evaluateCondition(condition, ctx.Attributes)
				}

				if result {
					switch policy.Effect {
					case pms.Grant:
						grantedPolicyList = append(grantedPolicyList, policy)
					case pms.Deny:
						deniedPolicyList = append(deniedPolicyList, policy)
					default:
						// TODO: Log a warning, currently do nothing.
					}
				} else if evaluationResult != nil {
					//addConditionFailedPolicyToEvaluationResult(policy, result, evaluationResult)
					evaluationResult.AddPolicy(policy, adsapi.Evaluation_ConditionFailed, result)
				}
			}
		}
	}
	return grantedPolicyList, deniedPolicyList, nil
}

// dataSet should be this:
//
//	{
//	  [] string, //service name slice
//	  map[int]string, //map of policy ID to it's serviceName
//	  map[int]string, //map of rolePolicy ID to it's serviceName
//	  [] string, //custom function slice
//	}
func (p *PolicyEvalImpl) syncRuntimeCache(dataSet []interface{}) error {
	logging.Default().Info("start to sync runtime cache data.")
	if len(dataSet) != 4 {
		return errors.New(errors.EvalCacheError, "invalid data set for cache reloading")
	}
	policyStore := p.Store
	logging.Default().Info("start to sync service data.")
	if serviceArr, ok := dataSet[0].([]string); ok {
		for _, serviceInDB := range serviceArr { //add new services
			if p.RuntimePolicyStore.RuntimeServices[serviceInDB] == nil {
				service, err := policyStore.GetService(serviceInDB)
				if err != nil {
					return err
				}
				if err := p.addServiceInRuntimeCache(service); err != nil {
					return err
				}
			}
		}

		for serviceInCache := range p.RuntimePolicyStore.RuntimeServices {
			isInDB := false
			for _, serviceInDB := range serviceArr {
				if serviceInDB == serviceInCache {
					isInDB = true
					break
				}
			}
			if !isInDB {
				p.deleteService(serviceInCache)
			}
		}
	} else {
		return errors.New(errors.EvalCacheError, "invalid service data set for cache reloading")
	}
	logging.Default().Info("start to sync policy data.")
	if policySetInDB, ok := dataSet[1].(map[int]string); ok {
		idInDB := getSortedIndexOfMap(policySetInDB)
		policySetInCache, idInCache, err := p.getPolicySetInCache()
		if err != nil {
			return err
		}
		missed, removed := difPolicySets(idInCache, idInDB)
		for _, id := range missed {
			serviceName := policySetInDB[id]
			policy, err := policyStore.GetPolicy(serviceName, strconv.Itoa(id))
			if err != nil {
				return err
			} else {
				if err := p.addPolicyInRuntimeCache(serviceName, policy); err != nil {
					return err
				}
			}
		}
		for _, id := range removed {
			serviceName := policySetInCache[id]
			p.DeletePolicyInRuntimeCache(serviceName, strconv.Itoa(id))
		}
	} else {
		return errors.New(errors.EvalCacheError, "invalid policy data set for cache reloading")
	}
	logging.Default().Info("start to sync rolePolicy data.")
	if rolePolicySetInDB, ok := dataSet[2].(map[int]string); ok {
		idInDB := getSortedIndexOfMap(rolePolicySetInDB)
		rolePolicySetInCache, idInCache, err := p.getRolePolicySetInCache()
		if err != nil {
			return err
		}
		missed, removed := difPolicySets(idInCache, idInDB)
		for _, id := range missed {
			serviceName := rolePolicySetInDB[id]
			policy, err := policyStore.GetRolePolicy(serviceName, strconv.Itoa(id))
			if err != nil {
				return err
			} else {
				if err := p.addRolePolicyInRuntimeCache(serviceName, policy); err != nil {
					return err
				}
			}
		}
		for _, id := range removed {
			serviceName := rolePolicySetInCache[id]
			p.DeleteRolePolicyInRuntimeCache(serviceName, strconv.Itoa(id))
		}
	} else {
		return errors.New(errors.EvalCacheError, "invalid rolePolicy data set for cache reloading")
	}
	logging.Default().Info("start to sync custom functions.")
	if CustFuncSetInDB, ok := dataSet[3].([]string); ok {
		custFuncSetInCache, err := p.getCustFunctionSetInCache()
		if err != nil {
			return err
		}
		missed, removed := difFuncSets(custFuncSetInCache, CustFuncSetInDB)
		for _, name := range missed {
			function, err := policyStore.GetFunction(name)
			if err != nil {
				return err
			} else {
				if err := p.addFunctionInRuntimeCache(function); err != nil {
					return err
				}
			}
		}
		for _, name := range removed {
			p.DeleteFunctionInRuntimeCache(name)
		}
	} else {
		return errors.New(errors.EvalCacheError, "invalid custom function data set for cache reloading")
	}
	logging.Default().Info("finished sync of runtime cache.")
	return nil
}

func getSortedIndexOfMap(m map[int]string) []int {
	var idx []int
	for i := range m {
		idx = append(idx, i)
	}
	sort.Ints(idx)
	return idx
}

func (p *PolicyEvalImpl) getPolicySetInCache() (map[int]string, []int, error) {
	resultSet := make(map[int]string)
	var idx []int
	for _, rService := range p.RuntimePolicyStore.RuntimeServices {
		for pId := range rService.PoliciesCache.PolicyMap {
			id, err := strconv.Atoi(pId)
			if err != nil {
				return nil, nil, errors.Wrapf(err, errors.EvalCacheError, "unable to convert policy ID %q", pId)
			}
			idx = append(idx, id)
			resultSet[id] = rService.Name
		}
	}
	sort.Ints(idx)
	return resultSet, idx, nil
}

func (p *PolicyEvalImpl) getRolePolicySetInCache() (map[int]string, []int, error) {
	resultSet := make(map[int]string)
	var idx []int
	for _, rService := range p.RuntimePolicyStore.RuntimeServices {
		for pId := range rService.RolePoliciesCache.PolicyMap {
			id, err := strconv.Atoi(pId)
			if err != nil {
				return nil, nil, errors.Wrapf(err, errors.EvalCacheError, "unable to convert policy ID %q", pId)
			}
			idx = append(idx, id)
			resultSet[id] = rService.Name
		}
	}
	sort.Ints(idx)
	return resultSet, idx, nil
}

func (p *PolicyEvalImpl) getCustFunctionSetInCache() ([]string, error) {
	resultSet := []string{}
	for funcName := range p.RuntimePolicyStore.Functions {
		if _, ok := builtinFunctions[funcName]; !ok {
			resultSet = append(resultSet, funcName)
		}
	}
	return resultSet, nil
}

func (p *PolicyEvalImpl) updateRuntimeCacheWithStoreChange(updateChan pms.StorageChangeChannel) {
	for e := range updateChan {
		_ = p.applyStoreChange(e)
	}
}

func (p *PolicyEvalImpl) applyStoreChange(e pms.StoreChangeEvent) (err error) {
	p.cacheGate.Lock()
	defer func() {
		if err != nil {
			if _, panicked := err.(*recoveredEvaluationError); panicked || e.Type != pms.FULL_RELOAD {
				p.cacheFailed.Store(true)
			}
		}
		p.cacheGate.Unlock()
	}()
	defer recoverEvaluation("StoreChange", &err)
	switch e.Type {
	case pms.STORE_UNAVAILABLE:
		p.storeUnavailableLocked()
	case pms.SERVICE_ADD: ///Event content: StoreUpdateData{ParentID:serviceName, Data:*service}
		serviceGot := e.Content.(*pms.Service)
		if err := p.addServiceInRuntimeCache(serviceGot); err != nil {
			return err
		}
	case pms.SERVICE_DELETE: //Event content:[]StoreUpdateData{ParentID:serviceName, Data:servieName}
		services := e.Content.([]string)
		for _, s := range services {
			p.deleteService(s)
		}
	case pms.POLICY_ADD: //Event content :[]StoreUpdateData{ParentID:serviceName, Data:*policy}
		data := e.Content.([]pms.StoreUpdateData)
		for _, s := range data {
			policy := s.Data.(*pms.Policy)
			if err := p.addPolicyInRuntimeCache(s.ServiceName, policy); err != nil {
				return err
			}
		}
	case pms.POLICY_DELETE: // Event content:[]StoreUpdateData{ParentID:serviceName, Data:*pms.Policy}
		data := e.Content.([]pms.StoreUpdateData)
		for _, s := range data {
			policy := s.Data.(*pms.Policy)
			p.DeletePolicyInRuntimeCache(s.ServiceName, policy.ID)
		}
	case pms.ROLEPOLICY_ADD: //Event content :[]StoreUpdateData{ParentID:serviceName, Data:*rolepolicy}
		data := e.Content.([]pms.StoreUpdateData)
		for _, s := range data {
			rolepolicy := s.Data.(*pms.RolePolicy)
			if err := p.addRolePolicyInRuntimeCache(s.ServiceName, rolepolicy); err != nil {
				return err
			}
		}
	case pms.ROLEPOLICY_DELETE: //Event content:[]StoreUpdateData{ParentID:serviceName, Data:*pms.RolePolicy}
		data := e.Content.([]pms.StoreUpdateData)
		for _, s := range data {
			rolePolicy := s.Data.(*pms.RolePolicy)
			p.DeleteRolePolicyInRuntimeCache(s.ServiceName, rolePolicy.ID)
		}
	case pms.SYNC_RELOAD:
		data := e.Content.([]interface{})
		err := p.syncRuntimeCache(data)
		if err != nil {
			logging.Default().Error(fmt.Sprint("failed to reload cache data. ", err))
			return err
		}
	case pms.FUNCTION_ADD:
		f := e.Content.(*pms.Function)
		if err := p.addFunctionInRuntimeCache(f); err != nil {
			return err
		}
	case pms.FUNCTION_DELETE:
		fs := e.Content.([]string)
		for _, f := range fs {
			p.DeleteFunctionInRuntimeCache(f)
		}
	case pms.FULL_RELOAD:
		if snapshot, ok := e.Content.(*pms.PolicyStore); ok && snapshot != nil {
			if err := p.RuntimePolicyStore.reloadPolicyStore(snapshot); err != nil {
				p.cacheFailed.Store(true)
				return err
			}
			p.storeAvailableLocked()
		} else {
			return p.fullReloadRuntimeCache()
		}
	}
	return nil
}

// Close releases evaluator resources, including a closable backing store.
// NewWithStore callers should close the evaluator only when they also intend
// to close the supplied store. StopWatch alone leaves the store usable.
func (p *PolicyEvalImpl) Close() error {
	p.closeOnce.Do(func() {
		p.closed.Store(true)
		if p.cleanupStop != nil {
			close(p.cleanupStop)
		}
		p.StopWatch()
		if closer, ok := p.Store.(io.Closer); ok {
			p.closeErr = closer.Close()
		}
	})
	return p.closeErr
}

// StopWatch stops watching policy store.
// After stopping watching, policy changes will not be updated automatically
func (p *PolicyEvalImpl) StopWatch() {
	p.watchStopped.Store(true)
	p.watchStopOnce.Do(func() {
		p.watchLifecycleMu.Lock()
		defer p.watchLifecycleMu.Unlock()
		p.Store.StopWatch()
	})
}

func difPolicySets(oldSet, newSet []int) (missed, removed []int) {
	var missedData, removedData []int
	i := 0
	j := 0
	for i <= len(oldSet) && j <= len(newSet) {

		if i == len(oldSet) { //add all data in newSet to missed
			missedData = append(missedData, newSet[j:]...)
			break
		}
		if j == len(newSet) { //add all data in oldSet to removed
			removedData = append(removedData, oldSet[i:]...)
			break
		}

		// Both sets are sorted: the smaller ID is missing from the other set.
		if oldSet[i] == newSet[j] {
			i++
			j++
		} else if oldSet[i] < newSet[j] {
			removedData = append(removedData, oldSet[i])
			i++
		} else {
			missedData = append(missedData, newSet[j])
			j++
		}
	}
	return missedData, removedData
}

func difFuncSets(oldSet, newSet []string) (missed, removed []string) {
	if len(oldSet) == 0 {
		return newSet, nil
	}
	if len(newSet) == 0 {
		return nil, oldSet
	}
	missed = []string{}
	removed = []string{}
	newMap := make(map[string]bool)
	for _, v := range newSet {
		newMap[v] = true
	}
	oldMap := make(map[string]bool)
	for _, v := range oldSet {
		oldMap[v] = true
	}
	for _, v := range newSet {
		if !oldMap[v] {
			missed = append(missed, v)
		}
	}
	for _, v := range oldSet {
		if !newMap[v] {
			removed = append(removed, v)
		}
	}
	return missed, removed

}
